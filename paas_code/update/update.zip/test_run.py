from ansible_api import MyRunner
#
#ansible = MyRunner('/etc/ansible/hosts')


ansible = MyRunner('./getHost.py')
#ansible.run('renders', 'copy', "src=./update.tar.gz dest=/home/update")
ansible.run('renders', 'unarchive', "src=/home/update/update.tar.gz dest=/home/update")
result=ansible.get_result()
succ = result['success']

failed = result['failed']
unreachable = result['unreachable']
for key,value in succ.iteritems():
    print key,value
